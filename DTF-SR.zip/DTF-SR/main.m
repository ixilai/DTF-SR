%         Xiaosong Li,Fuqiang Zhou, Haishu Tan,et al. Multimodal Medical Image Fusion Based on Joint Bilateral
%         Filter and Local Gradient Energy [J].Information Sciences, Accept
%         Beihang university,

% close all; clear all; clc;
function IF=main(A,B)



addpath tools
addpath functions
addpath ompbox10
addpath KSVD_Matlab_ToolBox
addpath cof
addpath ksvdbox13
addpath roll
addpath source image


f1=im2double(A);
f2=im2double(B);
if size(f1,3)>1
    f1=rgb2gray(f1);     
end
if size(f2,3)>1
    f2=rgb2gray(f2);           
end
tic

%figure,imshow(f1);   figure,imshow(f2);
D=cell2mat(struct2cell(load('D3.mat')));
%%zaosheng
sigma=0;  % noise level: 0,10,20,30,...
if sigma>0 
    v=sigma*sigma/(255*255);  
    f1=imnoise(f1,'gaussian',0,v);
    f2=imnoise(f2,'gaussian',0,v);
    
end

tic

%%
lambda = 1;  
npad = 10;    

[lowpass1, high1] = lowpass(f1, lambda, npad);
[lowpass2, high2] = lowpass(f2, lambda, npad);
%lowpass1= RollingGuidanceFilter(f1,3,0.05,5);
%lowpass2= RollingGuidanceFilter(f2,3,0.05,5);
%high1=f1-lowpass1;
%high2=f2-lowpass2;
 %imwrite(lowpass1,'E:\1111\lowpass1.tif');
 %imwrite(lowpass2,'E:\1111\lowpass2.tif');
 %imwrite(high1,'E:\1111\high1.tif');
 %imwrite(high2,'E:\1111\high2.tif');
%figure,imshow(high1,[]);figure,imshow(high2,[]);
%% lowpass fusion
% Smoothing
GA = im2double(lowpass1);
GB = im2double(lowpass2);
%figure,imshow(GA);figure,imshow(GB);

r = 3;
h = [1 -1];
[hei, wid] = size(GA);
N = boxfilter(ones(hei, wid), r);
Ga= RollingGuidanceFilter(GA,3,0.05,7);
Gb= RollingGuidanceFilter(GB,3,0.05,7);
%Ga = smoothing(GA, r, lambda,N);
%Gb = smoothing(GB, r, lambda,N);
%figure,imshow(Ga);figure,imshow(Gb);
%figure,imshow(Ga);figure,imshow(Gb);

%%
MA = abs(conv2(Ga,h,'same')) + ...
     abs(conv2(Ga,h','same'));
MB = abs(conv2(Gb,h,'same')) + ...
     abs(conv2(Gb,h','same'));
%figure,imshow(MA);figure,imshow(MB);
d = MA - MB;
%figure,imshow(d);
IA = boxfilter(d,r) ./ N>0;
IB=1-IA;
%figure,imshow(IB);
 %imwrite(IB,'E:\1111\1.tif');
%%
for t = 1:6
            IA = double(IA > 0.5);
            IA = RF(IA, 15 , 0.3, 1, GA);
end
figure,imshow(IA);
IB=1-IA;
% imwrite(IB,['E:\1111\2.tif']);
%%
%figure,imshow(IB);
% imwrite(IB,'C:\Users\22141\Desktop\过程\3.tif');
fused_low=im2double(lowpass1).*IA+IB.*im2double(lowpass2);

figure,imshow(fused_low);
%imwrite(fused_low,'E:\1111\fused_low.tif');

%%  highpass fusion
overlap=7;   
epsilon=0.01;  
C=0.0035;
if sigma==0
    epsilon=0.01;    
else
    epsilon=0.05++8*C*sigma;
end

fused_high=sparse_fusion(high1,high2,D,overlap,epsilon);

IF=fused_high+fused_low;

end                      

